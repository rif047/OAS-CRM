let User = require('./User_Model');
let bcrypt = require("bcrypt");
const { isReservedUsername, BUILTIN_ADMIN_USER } = require("../../Config/Builtin_Admin");
const { sanitizeAssignedCompanies } = require('../../Config/Companies');
const { handleControllerError } = require('../../Utils/ControllerError');
const BUILTIN_ADMIN_ID = BUILTIN_ADMIN_USER._id;

const PUBLIC_USER_FIELDS = '-password -secret_code';
const USER_OPTION_FIELDS = 'name username userType assignedCompanies';


let Users = async (req, res) => {
    const summaryOnly = String(req.query.summary || '').trim() === '1';
    const selectFields = summaryOnly ? 'userType createdAt' : PUBLIC_USER_FIELDS;
    let Data = await User.find().select(selectFields).sort({ createdAt: -1 }).lean();
    res.status(200).json(Data);
}

let UserOptions = async (req, res) => {
    let Data = await User.find().select(USER_OPTION_FIELDS).sort({ createdAt: -1 }).lean();
    res.status(200).json(Data);
}




let Create = async (req, res) => {
    try {
        let { name, phone, username, userType, email, password, secret_code, designation, description, assignedCompanies } = req.body;
        const normalizedUsername = String(username || "").toLowerCase();
        const safeAssignedCompanies = sanitizeAssignedCompanies(assignedCompanies);

        if (!name) { return res.status(400).send('Name is required!'); }
        if (!phone) { return res.status(400).send('Phone is required!'); }
        if (!username) { return res.status(400).send('Username is required!'); }
        if (!email) { return res.status(400).send('Email is required!'); }
        if (!password) { return res.status(400).send('Password is required!'); }
        if (!secret_code) { return res.status(400).send('Secret Code is required!'); }
        if (!designation) { return res.status(400).send('Designation is required!'); }
        if (isReservedUsername(normalizedUsername)) { return res.status(400).send('Username is reserved. Use different one.'); }


        let checkUserName = await User.findOne({ username: normalizedUsername });
        if (checkUserName) { return res.status(400).send('Username already exists. Use different one.'); };

        let checkPhone = await User.findOne({ phone });
        if (checkPhone) { return res.status(400).send('Phone already exists. Use different one.'); };

        let checkEmail = await User.findOne({ email });
        if (checkEmail) { return res.status(400).send('Email already exists. Use different one.'); };


        let hashPassword = await bcrypt.hash(password, 10);

        let newData = new User({
            name,
            phone,
            userType,
            designation,
            description,
            username: normalizedUsername,
            email: email.toLowerCase(),
            password: hashPassword,
            secret_code: secret_code.toLowerCase(),
            assignedCompanies: safeAssignedCompanies
        });

        await newData.save();
        const safeUser = await User.findById(newData._id).select(PUBLIC_USER_FIELDS).lean();
        res.status(200).json(safeUser);
        console.log('Created Successfully');

    } catch (error) {
        console.error(error);
        return handleControllerError(res, error, 'Creation Error!!!');
    }
}






let View = async (req, res) => {
    if (req.params.id === BUILTIN_ADMIN_ID) {
        return res.status(200).json(BUILTIN_ADMIN_USER);
    }
    let viewOne = await User.findById(req.params.id).select(PUBLIC_USER_FIELDS).lean();
    if (!viewOne) return res.status(404).send('User not found');
    res.send(viewOne)
}




let Update = async (req, res) => {
    try {
        let { name, phone, username, userType, email, password, secret_code, designation, description, assignedCompanies } = req.body;
        const normalizedUsername = String(username || "").toLowerCase();
        const safeAssignedCompanies = sanitizeAssignedCompanies(assignedCompanies);

        if (!name) { return res.status(400).send('Name is required!'); }
        if (!phone) { return res.status(400).send('Phone is required!'); }
        if (!username) { return res.status(400).send('Username is required!'); }
        if (!email) { return res.status(400).send('Email is required!'); }
        if (!secret_code) { return res.status(400).send('Secret Code is required!'); }
        if (!designation) { return res.status(400).send('Designation is required!'); }
        if (isReservedUsername(normalizedUsername)) { return res.status(400).send('Username is reserved. Use different one.'); }

        let checkUserName = await User.findOne({ username: normalizedUsername, _id: { $ne: req.params.id } });
        if (checkUserName) { return res.status(400).send('Username already exists. Use different one.'); }

        let checkPhone = await User.findOne({ phone: phone, _id: { $ne: req.params.id } });
        if (checkPhone) { return res.status(400).send('Phone already exists. Use different one.'); }

        let checkEmail = await User.findOne({ email: email.toLowerCase(), _id: { $ne: req.params.id } });
        if (checkEmail) { return res.status(400).send('Email already exists. Use different one.'); }

        if (req.params.id === BUILTIN_ADMIN_ID) {
            return res.status(403).send('System Administrator cannot be updated through this route.');
        }

        let updateData = await User.findById(req.params.id);
        if (!updateData) { return res.status(404).send('User not found'); }

        updateData.name = name;
        updateData.phone = phone;
        updateData.userType = userType;
        updateData.designation = designation;
        updateData.description = description;
        updateData.username = normalizedUsername;
        updateData.email = email.toLowerCase();
        updateData.secret_code = secret_code.toLowerCase();
        updateData.assignedCompanies = safeAssignedCompanies;

        if (password) {
            let hashPassword = await bcrypt.hash(password, 10);
            updateData.password = hashPassword;
        }

        await updateData.save();
        const safeUser = await User.findById(updateData._id).select(PUBLIC_USER_FIELDS).lean();
        res.status(200).json(safeUser);
        console.log('Updated Successfully');

    } catch (error) {
        console.error(error);
        return handleControllerError(res, error, 'Updating Error!!!');
    }
}





let Delete = async (req, res) => {
    if (req.params.id === BUILTIN_ADMIN_ID) {
        return res.status(403).send('System Administrator cannot be deleted.');
    }
    const deleted = await User.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).send('User not found');
    res.status(200).send('Deleted')
}




module.exports = { Users, UserOptions, Create, View, Update, Delete }
